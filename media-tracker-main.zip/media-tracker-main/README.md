A website that has a community managed database for books, movies and tv series with personal account based media consumption log functionality

It isn't maintained anymore, I sometimes decide to work on it but it was for a school project and I did not proceed much further from that.
